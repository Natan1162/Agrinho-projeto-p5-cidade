// Variáveis para a posição do avião
let aviaoX;
let aviaoY;

// Variáveis para a posição das nuvens
let nuvem1X;
let nuvem2X;
let nuvem3X;

// Array para os veículos (agora apenas carros)
let veiculos = [];

// Array para as pessoas
let pessoas = [];

// Array para as estrelas
let estrelas = [];

function setup() {
  createCanvas(800, 600); // Cria um canvas de 800x600 pixels
  aviaoX = width / 2;    // Começa o avião no centro horizontal
  aviaoY = height / 4;   // Começa o avião mais para cima

  // Posições iniciais aleatórias para as nuvens
  nuvem1X = random(width);
  nuvem2X = random(width);
  nuvem3X = random(width);

  // --- Definindo alturas base para posicionamento no setup (para a rua da frente) ---
  const alturaCalcadaPrincipal = 30;
  const alturaRuaPrincipal = 70;
  const yCalcadaPrincipalSetup = height - alturaCalcadaPrincipal;
  const yRuaPrincipalSetup = yCalcadaPrincipalSetup - alturaRuaPrincipal;
  const yMeioRuaSetup = yRuaPrincipalSetup + alturaRuaPrincipal / 2; // Posição Y do centro da rua

  // --- Cria apenas carros iniciais ---
  for (let i = 0; i < 5; i++) { // Aumentei o número de carros, já que não haverá motos e caminhões
    veiculos.push(new Carro(random(width), yMeioRuaSetup, random(2, 5)));
  }

  // --- Cria algumas pessoas iniciais ---
  for (let i = 0; i < 10; i++) { // Cria 10 pessoas
    pessoas.push(new Pessoa(random(width), yCalcadaPrincipalSetup, random(-1, 1)));
  }

  // Cria as estrelas uma única vez no setup
  for (let i = 0; i < 150; i++) {
    estrelas.push({
      x: random(width),
      y: random(height * 0.7),
      tamanho: random(1, 3),
      brilho: random(100, 255)
    });
  }
}

function draw() {
  // --- 1. FUNDO E CÉU (sempre desenhados primeiro) ---
  desenharCeuNoturno();
  desenharEstrelas();
  desenharLua(width - 100, 100, 80); // Desenha a lua no canto superior direito

  // Desenha e move as nuvens
  let velocidadeNuvem = 0.8;

  nuvem1X += velocidadeNuvem;
  if (nuvem1X > width + 100) {
    nuvem1X = -100;
  }
  desenharNuvem(nuvem1X, height * 0.1, 80);

  nuvem2X += velocidadeNuvem * 0.8;
  if (nuvem2X > width + 100) {
    nuvem2X = -100;
  }
  desenharNuvem(nuvem2X, height * 0.15, 100);

  nuvem3X += velocidadeNuvem * 1.2;
  if (nuvem3X > width + 100) {
    nuvem3X = -100;
  }
  desenharNuvem(nuvem3X, height * 0.05, 90);

  // --- 2. CHÃO DO FUNDO (Calçada para os prédios) ---
  const alturaCalcadaFundo = 40;
  const yCalcadaFundo = height - 120;
  desenharCalcada(yCalcadaFundo, alturaCalcadaFundo, color(120));

  // --- 3. PRÉDIOS (agora sobre a calçada de fundo) ---
  desenharPredio(50, yCalcadaFundo - 180, 80, 180);
  desenharPredio(180, yCalcadaFundo - 230, 100, 230);
  desenharPredio(300, yCalcadaFundo - 130, 70, 130);
  desenharPredio(500, yCalcadaFundo - 280, 90, 280);
  desenharPredio(650, yCalcadaFundo - 200, 75, 200);

  // --- 4. CHÃO PRINCIPAL: RUA E CALÇADA (desenhadas ANTES dos elementos da frente) ---
  const alturaCalcadaPrincipal = 30;
  const yCalcadaPrincipal = height - alturaCalcadaPrincipal;

  const alturaRuaPrincipal = 70;
  const yRuaPrincipal = yCalcadaPrincipal - alturaRuaPrincipal;

  desenharRua(yRuaPrincipal, alturaRuaPrincipal);
  desenharCalcada(yCalcadaPrincipal, alturaCalcadaPrincipal, color(150));

  // --- 5. VEÍCULOS E PESSOAS (desenhados DEPOIS da rua/calçada principal) ---
  // Percorre o array 'veiculos' e chama mover e desenhar para cada um
  for (let veiculo of veiculos) {
    veiculo.mover();
    veiculo.desenhar();
  }

  for (let pessoa of pessoas) {
    pessoa.mover();
    pessoa.desenhar();
  }

  // --- 6. AVIÃO (sempre por cima de tudo) ---
  aviaoX += 2;
  if (aviaoX > width + 50) {
    aviaoX = -50;
  }
  desenharAviao(aviaoX, aviaoY);
}

// --- CLASSE BASE VEICULO (Para reutilizar o método mover) ---
class Veiculo {
  constructor(x, y, velocidade, largura, altura, cor) {
    this.x = x;
    this.y = y; // Y é a posição central vertical do objeto
    this.velocidade = velocidade;
    this.largura = largura;
    this.altura = altura;
    this.cor = cor;
  }

  mover() {
    this.x += this.velocidade;
    // Condições para reaparecer o veículo do outro lado da tela
    if (this.velocidade > 0 && this.x > width + this.largura / 2) {
      this.x = -this.largura / 2;
    } else if (this.velocidade < 0 && this.x < -this.largura / 2) {
      this.x = width + this.largura / 2;
    }
  }
}

// --- CLASSE CARRO (Herda de Veiculo) ---
class Carro extends Veiculo {
  constructor(x, y, velocidade) {
    // Carro: centro em Y é o Y passado, corpo desenhado com rectMode(CENTER)
    super(x, y, velocidade, 40, 20, color(random(255), random(255), random(255)));
  }

  desenhar() {
    push();
    translate(this.x, this.y);
    fill(this.cor);
    noStroke();
    rectMode(CENTER);
    rect(0, 0, this.largura, this.altura); // Corpo do carro
    fill(0); // Rodas
    ellipse(-this.largura / 2 + 10, this.altura / 2, 8, 8); // Rodas na parte inferior do carro
    ellipse(this.largura / 2 - 10, this.altura / 2, 8, 8);
    pop();
  }
}

// AS CLASSES MOTO E CAMINHAO FORAM REMOVIDAS DAQUI


// --- CLASSE PESSOA ---
class Pessoa {
  constructor(x, y, direcao) {
    this.x = x;
    this.y = y; // O Y da pessoa é a altura do topo da calçada
    this.direcao = direcao;
    this.velocidade = 1;
    this.altura = 30;
    this.largura = 15;
    this.corPele = color(random(180, 255), random(150, 220), random(120, 180));
    this.corRoupa = color(random(255), random(255), random(255));
  }

  mover() {
    this.x += this.direcao * this.velocidade;
    if (this.x < -this.largura || this.x > width + this.largura) {
      this.direcao *= -1;
    }
  }

  desenhar() {
    push();
    translate(this.x, this.y);

    // Desenha o corpo (roupa)
    fill(this.corRoupa);
    rect(-this.largura / 2, -this.altura, this.largura, this.altura); // Corpo

    // Desenha a cabeça (pele)
    fill(this.corPele);
    ellipse(0, -this.altura, this.largura, this.largura); // Cabeça no topo do corpo
    pop();
  }
}

// --- FUNÇÃO desenharAviao() ---
function desenharAviao(x, y) {
  push();
  translate(x, y);
  fill(180);
  noStroke();
  rect(-30, -10, 60, 20, 5);
  fill(100);
  arc(0, -10, 40, 20, PI, TWO_PI);
  fill(150);
  triangle(-20, 0, -60, 15, -20, 15);
  triangle(20, 0, 60, 15, 20, 15);
  fill(150);
  triangle(25, -10, 35, -25, 35, -10);
  fill(150);
  rect(10, 5, 20, 5);
  fill(255);
  ellipse(-10, -5, 5, 5);
  ellipse(0, -5, 5, 5);
  ellipse(10, -5, 5, 5);
  pop();
}

// --- FUNÇÃO desenharCeuNoturno() ---
function desenharCeuNoturno() {
  noStroke();
  let corTopoNoite = color(0, 0, 30);
  let corBaseNoite = color(0, 0, 80);
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(corTopoNoite, corBaseNoite, inter);
    fill(c);
    rect(0, y, width, 1);
  }
}

// --- FUNÇÃO desenharEstrelas() ---
function desenharEstrelas() {
  noStroke();
  for (let estrela of estrelas) {
    let brilhoAtual = map(sin(frameCount * 0.05 + estrela.x * 0.01), -1, 1, estrela.brilho * 0.5, estrela.brilho);
    fill(255, 255, 255, brilhoAtual);
    ellipse(estrela.x, estrela.y, estrela.tamanho, estrela.tamanho);
  }
}

// --- FUNÇÃO desenharNuvem() ---
function desenharNuvem(x, y, tamanho) {
  fill(220, 220, 220, 150);
  noStroke();
  ellipse(x, y, tamanho * 0.8, tamanho * 0.6);
  ellipse(x + tamanho * 0.3, y - tamanho * 0.1, tamanho * 0.7, tamanho * 0.5);
  ellipse(x - tamanho * 0.3, y - tamanho * 0.1, tamanho * 0.7, tamanho * 0.5);
  ellipse(x + tamanho * 0.1, y + tamanho * 0.2, tamanho * 0.6, tamanho * 0.4);
}

// --- FUNÇÃO desenharPredio() ---
function desenharPredio(x, y, largura, altura) {
  fill(100);
  rect(x, y, largura, altura);
  fill(200, 200, 0); // Janelas acesas e estáticas
  let janelaLargura = largura / 5;
  let janelaAltura = altura / 8;
  for (let i = 0; i < altura / janelaAltura - 1; i++) {
    for (let j = 0; j < largura / janelaLargura - 1; j++) {
      rect(
        x + janelaLargura * 0.5 + j * janelaLargura,
        y + janelaAltura * 0.5 + i * janelaAltura,
        janelaLargura * 0.7,
        janelaAltura * 0.7
      );
    }
  }
}

// --- FUNÇÃO desenharRua() ---
function desenharRua(yPos, alturaRua) {
  fill(50); // Cinza escuro para a rua
  rect(0, yPos, width, alturaRua); // Desenha a rua com a posição e altura passadas

  // Faixas da rua
  stroke(255, 255, 0); // Amarelo para as faixas
  strokeWeight(3);
  for (let i = 0; i < width; i += 40) { // Faixas tracejadas
    line(i, yPos + alturaRua / 2, i + 20, yPos + alturaRua / 2); // Centraliza as faixas
  }
  noStroke(); // Remove o contorno após desenhar as faixas
}

// --- FUNÇÃO desenharCalcada() ---
function desenharCalcada(yPos, alturaCalcada, corCalcada) {
  fill(corCalcada);
  rect(0, yPos, width, alturaCalcada);
}

// --- FUNÇÃO desenharLua() ---
function desenharLua(x, y, diametro) {
  fill(220, 220, 200);
  noStroke();
  ellipse(x, y, diametro, diametro);

  fill(180, 180, 160, 150);
  ellipse(x - diametro * 0.15, y - diametro * 0.2, diametro * 0.25, diametro * 0.2);
  ellipse(x + diametro * 0.2, y + diametro * 0.1, diametro * 0.3, diametro * 0.25);
  ellipse(x, y + diametro * 0.3, diametro * 0.15, diametro * 0.1);
}